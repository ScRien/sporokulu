import mongoose from "mongoose";

const studentSchema = new mongoose.Schema(
  {
    // ============================
    // TEMEL BİLGİLER
    // ============================
    name: { type: String, required: true },
    age: { type: Number, required: true },
    gender: { type: String, enum: ["Erkek", "Kız"], default: "Erkek" },
    birthDate: { type: Date },

    // ============================
    // AİLE BİLGİLERİ
    // ============================
    mother: {
      name: String,
      phone: String,
      email: String,
    },

    father: {
      name: String,
      phone: String,
      email: String,
    },

    // ============================
    // İKİNCİL VELİ
    // ============================
    guardian: {
      name: String,
      phone: String,
      relation: String, // teyze, amca, dede...
    },

    // ============================
    // ADRES & İLETİŞİM
    // ============================
    phone: { type: String },
    address: { type: String },
    city: { type: String },
    district: { type: String },

    // ============================
    // SPOR BİLGİLERİ
    // ============================
    branch: { type: String, required: true }, // Futbol, Basketbol, Yüzme...
    level: { type: String, default: "Başlangıç" }, 
    status: {
      type: String,
      enum: ["aktif", "pasif", "donduruldu", "ayrıldı"],
      default: "Aktif",
    },

    // ============================
    // NOTLAR & ÜCRET
    // ============================
    notes: { type: String },
    monthlyFee: { type: Number }, // Aylık ücret

    // ============================
    // SİSTEMSEL
    // ============================
    startDate: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default mongoose.models.Student || mongoose.model("Student", studentSchema);