import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true
    },

    amount: {
      type: Number,
      required: true
    },

    // Ödeme tarihi (fiili yapılan tarih)
    date: {
      type: Date,
      default: Date.now
    },

    // Aylık takip için:
    month: {          // 1-12 arası
      type: Number,
      required: true
    },

    year: {           // 2025, 2026...
      type: Number,
      required: true
    },

    note: {
      type: String
    },

    status: {
      type: String,
      enum: ["ödendi", "bekliyor"],
      default: "bekliyor"
    }
  },
  { timestamps: true }
);

export default mongoose.models.Payment || mongoose.model("Payment", paymentSchema);