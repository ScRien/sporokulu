import express from "express";
import bcrypt from "bcryptjs";
import User from "../models/User.js";
import { requireAdmin } from "../middlewares/auth.js";

const settingsRouter = express.Router();

// ========== AYARLAR SAYFASI ==========
settingsRouter.get("/admin/settings", requireAdmin, async (req, res) => {
  const admin = await User.findById(req.session.user.id);

  res.render("pages/settings/index", {
    title: "Ayarlar",
    admin
  });
});


// ========== ŞİFRE GÜNCELLE ==========
settingsRouter.post("/admin/settings/password", requireAdmin, async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const admin = await User.findById(req.session.user.id);

  const isMatch = await bcrypt.compare(currentPassword, admin.password);
  if (!isMatch) {
    return res.render("pages/settings/index", {
      title: "Ayarlar",
      admin,
      error: "Mevcut şifre yanlış!"
    });
  }

  const hashed = await bcrypt.hash(newPassword, 10);

  admin.password = hashed;
  await admin.save();

  res.render("pages/settings/index", {
    title: "Ayarlar",
    admin,
    success: "Şifre başarıyla güncellendi!"
  });
});

export default settingsRouter;
