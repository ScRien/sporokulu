// routes/attendance.js
import express from "express";
import Attendance from "../models/Attendance.js";
import Student from "../models/Student.js";
import { requireAdmin } from "../middlewares/auth.js";

const attendanceRouter = express.Router();

/* ---------------------------------------------------
   1) TÜM YOKLAMALAR (liste sayfası)
------------------------------------------------------*/
attendanceRouter.get("/admin/attendance/list", requireAdmin, async (req, res) => {
  const attendance = await Attendance.find()
    .populate("student")
    .sort({ date: -1 });

  res.render("pages/attendance/list", {
    title: "Yoklama Listesi",
    attendance
  });
});

/* ---------------------------------------------------
   2) GÜNLÜK YOKLAMA ALMA
------------------------------------------------------*/
attendanceRouter.get("/admin/attendance", requireAdmin, async (req, res) => {
  const students = await Student.find({ status: "aktif" }).sort({ name: 1 });

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  const todayAttendance = await Attendance.find({
    date: { $gte: todayStart, $lte: todayEnd }
  }).populate("student");

  res.render("pages/attendance/take", {
    title: "Günlük Yoklama",
    students,
    todayAttendance
  });
});

/* ---------------------------------------------------
   3) TOPLU YOKLAMA SAYFASI
------------------------------------------------------*/
attendanceRouter.get("/admin/attendance/bulk", requireAdmin, async (req, res) => {
  const branches = ["Futbol", "Basketbol", "Yüzme", "Voleybol"];

  const selectedBranch = req.query.branch || null;

  const students = selectedBranch
    ? await Student.find({ branch: selectedBranch, status: "aktif" }).sort({ name: 1 })
    : await Student.find({ status: "aktif" }).sort({ name: 1 });

  res.render("pages/attendance/bulk", {
    title: "Toplu Yoklama",
    students,
    branches,
    selectedBranch
  });
});

/* ---------------------------------------------------
   4) TOPLU YOKLAMA KAYDETME POST
------------------------------------------------------*/
attendanceRouter.post("/admin/attendance/bulk", requireAdmin, async (req, res) => {
  const { attendance } = req.body;

  if (!attendance) return res.redirect("/admin/attendance/bulk");

  const today = new Date();
  const start = new Date(today.setHours(0, 0, 0, 0));
  const end = new Date(today.setHours(23, 59, 59, 999));

  for (const studentId in attendance) {
    const status = attendance[studentId];

    const exists = await Attendance.findOne({
      student: studentId,
      date: { $gte: start, $lte: end }
    });

    if (!exists) {
      await Attendance.create({
        student: studentId,
        date: new Date(),
        status
      });
    }
  }

  res.redirect("/admin/attendance/list");
});

/* ---------------------------------------------------
   5) TEK ÖĞRENCİ İÇİN YOKLAMA ALMA SAYFASI
------------------------------------------------------*/
attendanceRouter.get("/admin/attendance/new", requireAdmin, async (req, res) => {
  const students = await Student.find({ status: "aktif" }).sort({ name: 1 });

  res.render("pages/attendance/new", {
    title: "Tek Öğrenci Yoklaması",
    students
  });
});

/* ---------------------------------------------------
   6) TEK ÖĞRENCİ YOKLAMA KAYDET
------------------------------------------------------*/
attendanceRouter.post("/admin/attendance/new", requireAdmin, async (req, res) => {
  const { student, status } = req.body;

  await Attendance.create({
    student,
    status,
    date: new Date()
  });

  res.redirect("/admin/attendance/list");
});

/* ---------------------------------------------------
   7) DURUMU VAR ↔ YOK DEĞİŞTİRME
------------------------------------------------------*/
attendanceRouter.post("/admin/attendance/:id/toggle", requireAdmin, async (req, res) => {
  const att = await Attendance.findById(req.params.id);

  if (!att) return res.redirect("back");

  att.status = att.status === "var" ? "yok" : "var";
  await att.save();

  res.redirect("back");
});

/* ---------------------------------------------------
   8) YOKLAMA SİL
------------------------------------------------------*/
attendanceRouter.post("/admin/attendance/:id/delete", requireAdmin, async (req, res) => {
  await Attendance.findByIdAndDelete(req.params.id);
  res.redirect("back");
});

export default attendanceRouter;
