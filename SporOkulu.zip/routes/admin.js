    import express from "express";
import { requireAdmin } from "../middlewares/auth.js";

const adminRouter = express.Router();

adminRouter.get("/admin", requireAdmin, (req, res) => {
  res.render("pages/admin/dashboard", {
    title: "Yönetim Paneli",
    user: req.session.user
  });
});

export default adminRouter;