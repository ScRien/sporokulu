import express from "express";
import Payment from "../models/Payment.js";
import Student from "../models/Student.js";
import { requireAdmin } from "../middlewares/auth.js";
import PDFDocument from "pdfkit";
import fs from "fs";
import path from "path";

const paymentsRouter = express.Router();

// ========== ÖDEMELER LİSTESİ ==========
paymentsRouter.get("/admin/payments", requireAdmin, async (req, res) => {
  const payments = await Payment.find().populate("student").sort({ date: -1 });

  res.render("pages/payments/list", {
    title: "Ödemeler",
    payments,
  });
});

// ========== YENİ ÖDEME FORMU ==========
paymentsRouter.get("/admin/payments/new", requireAdmin, async (req, res) => {
  const students = await Student.find().sort({ name: 1 });

  res.render("pages/payments/new", {
    title: "Ödeme Ekle",
    students,
  });
});

// ========== ÖDEME EKLE POST ==========
paymentsRouter.post("/admin/payments", requireAdmin, async (req, res) => {
  try {
    await Payment.create(req.body);
    res.redirect("/admin/payments");
  } catch (err) {
    res.send("Hata oluştu: " + err);
  }
});

// ========== ÖDEME SİL ==========
paymentsRouter.post(
  "/admin/payments/:id/delete",
  requireAdmin,
  async (req, res) => {
    await Payment.findByIdAndDelete(req.params.id);
    res.redirect("/admin/payments");
  }
);

paymentsRouter.post(
  "/admin/payments/:id/mark-paid",
  requireAdmin,
  async (req, res) => {
    await Payment.findByIdAndUpdate(req.params.id, {
      status: "ödendi",
      date: new Date(),
    });

    res.redirect("back");
  }
);

paymentsRouter.post(
  "/admin/payments/:studentId/mark-all-paid",
  requireAdmin,
  async (req, res) => {
    const { studentId } = req.params;

    await Payment.updateMany(
      { student: studentId },
      { status: "ödendi", date: new Date() }
    );

    res.redirect("back");
  }
);

paymentsRouter.post(
  "/admin/payments/:studentId/mark-current-year-paid",
  requireAdmin,
  async (req, res) => {
    const { studentId } = req.params;
    const currentYear = new Date().getFullYear();

    await Payment.updateMany(
      { student: studentId, year: currentYear },
      { status: "ödendi", date: new Date() }
    );

    res.redirect("back");
  }
);

paymentsRouter.post(
  "/admin/payments/:studentId/mark-range-paid",
  requireAdmin,
  async (req, res) => {
    const { studentId } = req.params;
    const { startMonth, endMonth, year } = req.body;

    await Payment.updateMany(
      {
        student: studentId,
        month: { $gte: Number(startMonth), $lte: Number(endMonth) },
        year: Number(year),
      },
      { status: "ödendi", date: new Date() }
    );

    res.redirect("back");
  }
);

// ========== ÖDEME MAKBUZU PDF OLUŞTUR ==========
paymentsRouter.get(
  "/admin/payments/:id/receipt",
  requireAdmin,
  async (req, res) => {
    try {
      const payment = await Payment.findById(req.params.id).populate("student");

      if (!payment) {
        return res.send("Makbuz bulunamadı.");
      }

      // Makbuz numarası
      const receiptNo = "MBZ-" + payment._id.toString().slice(-6).toUpperCase();

      // PDF oluştur
      const doc = new PDFDocument({ size: "A4", margin: 50 });

      doc.registerFont(
        "TurkishFont",
        path.join("public", "fonts", "DejaVuSans.ttf")
      );
      doc.font("TurkishFont");

      // Response header
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `inline; filename=${receiptNo}.pdf`);

      doc.pipe(res);

      // Başlık
      doc.fontSize(20).text("SPOR OKULU ÖDEME MAKBUZU", { align: "center" });
      doc.moveDown(1);

      // Makbuz numarası
      doc.fontSize(12).text(`Makbuz No: ${receiptNo}`);
      doc.text(`Tarih: ${new Date().toLocaleDateString("tr-TR")}`);
      doc.moveDown();

      // ÖDEME BİLGİLERİ TABLOSU
      doc.fontSize(13).text("Ödeme Bilgileri", { underline: true });
      doc.moveDown(0.5);

      doc.fontSize(12).text(`Öğrenci Adı: ${payment.student.name}`);
      doc.text(`Branş: ${payment.student.branch}`);
      doc.text(`Tutar: ${payment.amount} ₺`);
      doc.text(`Ay / Yıl: ${payment.month}.${payment.year}`);
      doc.text(`Durum: ${payment.status.toUpperCase()}`);
      doc.text(`Not: ${payment.note || "-"}`);
      doc.moveDown(2);

      doc.text("İmza: __________________________", { align: "left" });

      doc.end();
    } catch (err) {
      console.log(err);
      res.send("PDF üretilemedi.");
    }
  }
);

export default paymentsRouter;
