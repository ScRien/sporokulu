import express from "express";
import Student from "../models/Student.js";
import Payment from "../models/Payment.js";
import Attendance from "../models/Attendance.js";
import { requireAdmin } from "../middlewares/auth.js";
import { createMonthlyPayments } from "../helpers/paymentGenerator.js";

const studentRouter = express.Router();


// ===========================================
// 1) ÖĞRENCİ LİSTESİ
// ===========================================
studentRouter.get("/admin/students", requireAdmin, async (req, res) => {
  const students = await Student.find().sort({ createdAt: -1 });

  res.render("pages/students/list", {
    title: "Öğrenci Listesi",
    students,
    user: req.session.user,
  });
});


// ===========================================
// 2) YENİ ÖĞRENCİ SAYFASI
// ===========================================
studentRouter.get("/admin/students/new", requireAdmin, (req, res) => {
  res.render("pages/students/new", {
    title: "Yeni Öğrenci Ekle",
    user: req.session.user,
  });
});


// ===========================================
// 3) YENİ ÖĞRENCİ EKLE POST
// ===========================================
studentRouter.post("/admin/students", requireAdmin, async (req, res) => {
  try {
    const {
      name,
      age,
      gender,
      birthDate,

      mother,
      father,
      guardian,

      phone,
      address,
      city,
      district,

      branch,
      level,
      status,
      notes,
      monthlyFee,
    } = req.body;

    // ---------------------
    // 1) ÖĞRENCİYİ KAYDET
    // ---------------------
    const newStudent = await Student.create({
      name,
      age,
      gender,
      birthDate,

      mother: {
        name: mother?.name || "",
        phone: mother?.phone || "",
        email: mother?.email || "",
      },

      father: {
        name: father?.name || "",
        phone: father?.phone || "",
        email: father?.email || "",
      },

      guardian: {
        name: guardian?.name || "",
        phone: guardian?.phone || "",
        relation: guardian?.relation || "",
      },

      phone,
      address,
      city,
      district,

      branch,
      level,
      status,
      notes,
      monthlyFee,
    });

    // ----------------------------------------------------
    // 2) OTOMATİK AYLIK ÖDEME PLANI OLUŞTUR (Profesyonel)
    // ----------------------------------------------------
    await createMonthlyPayments(newStudent._id, monthlyFee);

    res.redirect("/admin/students");

  } catch (err) {
    console.log("Öğrenci ekleme hatası:", err);

    res.render("pages/students/new", {
      title: "Yeni Öğrenci Ekle",
      error: "Bir hata oluştu. Lütfen bilgileri kontrol et.",
      user: req.session.user,
    });
  }
});


// ===========================================
// 4) ÖĞRENCİ DÜZENLEME SAYFASI
// ===========================================
studentRouter.get("/admin/students/:id/edit", requireAdmin, async (req, res) => {
  const student = await Student.findById(req.params.id);

  res.render("pages/students/edit", {
    title: "Öğrenciyi Düzenle",
    student,
    user: req.session.user,
  });
});


// ===========================================
// 5) ÖĞRENCİ GÜNCELLE POST
// ===========================================
studentRouter.post("/admin/students/:id", requireAdmin, async (req, res) => {
  try {
    const {
      name,
      age,
      gender,
      birthDate,

      mother,
      father,
      guardian,

      phone,
      address,
      city,
      district,

      branch,
      level,
      status,
      notes,
      monthlyFee,
    } = req.body;

    await Student.findByIdAndUpdate(req.params.id, {
      name,
      age,
      gender,
      birthDate,

      mother: {
        name: mother?.name || "",
        phone: mother?.phone || "",
        email: mother?.email || "",
      },

      father: {
        name: father?.name || "",
        phone: father?.phone || "",
        email: father?.email || "",
      },

      guardian: {
        name: guardian?.name || "",
        phone: guardian?.phone || "",
        relation: guardian?.relation || "",
      },

      phone,
      address,
      city,
      district,

      branch,
      level,
      status,
      notes,
      monthlyFee,
    });

    res.redirect("/admin/students");

  } catch (err) {
    console.log("Öğrenci güncelleme hatası:", err);

    res.render("pages/students/edit", {
      title: "Öğrenciyi Düzenle",
      error: "Bir hata oluştu. Lütfen tekrar deneyin.",
      student: await Student.findById(req.params.id),
      user: req.session.user,
    });
  }
});


// ===========================================
// 6) ÖĞRENCİ SİL
// ===========================================
studentRouter.post("/admin/students/:id/delete", requireAdmin, async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.redirect("/admin/students");
});


// ===========================================
// 7) ÖĞRENCİ DETAY SAYFASI (PROFILE)
// ===========================================
studentRouter.get("/admin/students/:id", requireAdmin, async (req, res) => {
  const id = req.params.id;

  const student = await Student.findById(id);

  const payments = await Payment.find({ student: id }).sort({ date: -1 });
  const attendance = await Attendance.find({ student: id }).sort({ date: -1 });

  const totalPaid = payments
    .filter((p) => p.status === "ödendi")
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPending = payments
    .filter((p) => p.status === "bekliyor")
    .reduce((sum, p) => sum + p.amount, 0);

  const attendancePresent = attendance.filter((a) => a.status === "var").length;
  const attendanceAbsent = attendance.filter((a) => a.status === "yok").length;

  res.render("pages/students/detail", {
    title: `${student.name} - Öğrenci Profil`,
    student,
    payments,
    attendance,
    totalPaid,
    totalPending,
    attendancePresent,
    attendanceAbsent,
  });
});


export default studentRouter;
