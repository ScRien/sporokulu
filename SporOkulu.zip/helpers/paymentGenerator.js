import Payment from "../models/Payment.js";

export async function createMonthlyPayments(studentId, monthlyFee) {
  const today = new Date();
  const startMonth = today.getMonth() + 1; // 1-12
  const currentYear = today.getFullYear();

  const payments = [];

  // 1) İçinde bulunulan aydan yıl sonuna kadar
  for (let month = startMonth; month <= 12; month++) {
    payments.push({
      student: studentId,
      amount: monthlyFee,
      status: "bekliyor",
      note: "Otomatik oluşturuldu",
      month,
      year: currentYear,
    });
  }

  // 2) Eğer yıl sonunda 12 ay tamamlanmadıysa -> gelecek yıldan tamamla
  const createdMonths = payments.length; // kaç ay oluşturduk
  const needed = 12 - createdMonths; // kalan ay miktarı

  if (needed > 0) {
    const nextYear = currentYear + 1;

    for (let month = 1; month <= needed; month++) {
      payments.push({
        student: studentId,
        amount: monthlyFee,
        status: "bekliyor",
        note: "Otomatik oluşturuldu",
        month,
        year: nextYear,
      });
    }
  }

  // Hepsini tek seferde kaydet
  await Payment.insertMany(payments);

  return payments;
}
